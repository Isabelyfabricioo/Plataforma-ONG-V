// assets/js/router.js
import { templates } from './templates.js';

export function loadPage(page) {
  const main = document.getElementById('main');
  if (!main) return;

  main.classList.add('fade');
  setTimeout(() => {
    main.innerHTML = templates[page] || '<h2>Página não encontrada</h2>';
    main.classList.remove('fade');

    // move focus to main for screen reader users
    const firstHeading = main.querySelector('h1, h2');
    if (firstHeading) {
      firstHeading.setAttribute('tabindex', '-1');
      firstHeading.focus();
    } else {
      main.focus();
    }

    window.dispatchEvent(new CustomEvent('page:loaded', { detail: { page } }));
  }, 150);
}

export function initRouter() {
  const current = location.hash.replace('#', '') || 'home';
  loadPage(current);

  window.addEventListener('hashchange', () => {
    const page = location.hash.replace('#', '') || 'home';
    loadPage(page);
  });
}