// assets/js/templates.js
export const templates = {
  home: `
    <section>
      <h1>Bem-vindo à ONG Exemplo</h1>
      <p>Promovendo inclusão, educação e solidariedade.</p>
      <a href="#cadastro" class="btn primary">Quero participar</a>
    </section>
  `,
  projetos: `
    <section>
      <h1>Projetos</h1>
      <ul class="cards" role="list">
        <li class="card" role="listitem">
          <div class="card-body">
            <h2 class="card-title">Educação para Todos</h2>
            <p class="card-desc">Aulas gratuitas para jovens e adultos.</p>
          </div>
        </li>
        <li class="card" role="listitem">
          <div class="card-body">
            <h2 class="card-title">Saúde em Movimento</h2>
            <p class="card-desc">Ações de saúde em comunidades carentes.</p>
          </div>
        </li>
      </ul>
    </section>
  `,
  cadastro: `
    <section>
      <h1>Cadastro</h1>
      <form id="cadastroForm" novalidate>
        <div class="field">
          <label for="nome">Nome</label>
          <input id="nome" name="nome" required aria-required="true" />
          <div class="field-error" aria-live="polite"></div>
        </div>
        <div class="field">
          <label for="email">E-mail</label>
          <input id="email" name="email" type="email" required aria-required="true" />
          <div class="field-error" aria-live="polite"></div>
        </div>
        <button type="submit" class="btn primary">Enviar</button>
      </form>
    </section>
  `
};