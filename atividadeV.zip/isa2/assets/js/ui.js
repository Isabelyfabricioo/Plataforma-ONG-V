// assets/js/ui.js
export function initUI() {
  const btnHamb = document.querySelector('.hamburger');
  const nav = document.getElementById('primary-nav');
  const btnTheme = document.getElementById('btnTheme');

  // Hamburger open/close + aria
  if (btnHamb && nav) {
    btnHamb.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btnHamb.setAttribute('aria-expanded', String(open));
      if (open) {
        // move focus to first link
        const firstLink = nav.querySelector('a');
        if (firstLink) firstLink.focus();
      } else {
        btnHamb.focus();
      }
    });

    // Close menu on Escape and handle keyboard navigation
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && nav.classList.contains('open')) {
        nav.classList.remove('open');
        btnHamb.setAttribute('aria-expanded', 'false');
        btnHamb.focus();
      }
    });

    // Close menu when clicking outside on mobile
    document.addEventListener('click', (e) => {
      if (!nav.contains(e.target) && !btnHamb.contains(e.target) && nav.classList.contains('open')) {
        nav.classList.remove('open');
        btnHamb.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Theme toggle with persistence
  const root = document.documentElement;
  const THEME_KEY = 'ong_tema';
  function applyTheme(name) {
    document.body.classList.toggle('dark-theme', name === 'dark');
    document.body.classList.toggle('high-contrast', name === 'contrast');
    if (btnTheme) {
      btnTheme.setAttribute('aria-pressed', String(name !== 'light'));
    }
  }

  // Load stored preference or system
  let stored = localStorage.getItem(THEME_KEY);
  if (!stored) {
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    stored = prefersDark ? 'dark' : 'light';
  }
  applyTheme(stored);

  if (btnTheme) {
    btnTheme.addEventListener('click', () => {
      const current = localStorage.getItem(THEME_KEY) || 'light';
      const next = current === 'light' ? 'dark' : (current === 'dark' ? 'contrast' : 'light');
      localStorage.setItem(THEME_KEY, next);
      applyTheme(next);
      showToast(next === 'dark' ? 'Modo escuro ativado' : next === 'contrast' ? 'Alto contraste ativado' : 'Modo claro ativado');
    });
  }
}

// Toast helper that uses aria-live region and visible toast
export function showToast(msg, ms = 3000) {
  let toast = document.getElementById('toast');
  const liveRoot = document.getElementById('toast-root');

  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }

  // update aria-live region for screen readers
  if (liveRoot) {
    liveRoot.classList.remove('sr-only');
    liveRoot.textContent = msg;
    // hide again after small delay to preserve sr-only semantics
    setTimeout(() => liveRoot.classList.add('sr-only'), 700);
  }

  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), ms);
}