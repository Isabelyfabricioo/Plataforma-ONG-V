// assets/js/form.js
import { showToast } from './ui.js';

export function initForm() {
  const form = document.getElementById('cadastroForm');
  if (!form) return;

  // add simple accessibility attributes to required inputs
  Array.from(form.elements).forEach(el => {
    if (el.required) el.setAttribute('aria-required', 'true');
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    const nomeEl = form.querySelector('#nome');
    const emailEl = form.querySelector('#email');
    const nome = nomeEl?.value.trim() || '';
    const email = emailEl?.value.trim() || '';

    // reset error
    [nomeEl, emailEl].forEach(el => {
      if (el) el.classList.remove('invalid');
      const err = el?.parentElement?.querySelector('.field-error');
      if (err) err.classList.remove('visible');
    });

    let invalid = false;
    if (!nome) {
      invalid = true;
      nomeEl.classList.add('invalid');
      const err = nomeEl.parentElement.querySelector('.field-error');
      if (err) { err.textContent = 'Nome é obrigatório'; err.classList.add('visible'); }
    }
    if (!email || !email.includes('@')) {
      invalid = true;
      emailEl.classList.add('invalid');
      const err = emailEl.parentElement.querySelector('.field-error');
      if (err) { err.textContent = 'E-mail inválido'; err.classList.add('visible'); }
    }

    if (invalid) {
      showToast('Preencha os campos corretamente!');
      return;
    }

    showToast('Cadastro enviado com sucesso!');
    form.reset();
  });
}