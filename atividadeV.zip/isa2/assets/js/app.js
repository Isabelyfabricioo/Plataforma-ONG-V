// assets/js/app.js
import { initRouter } from './router.js';
import { initUI } from './ui.js';
import { initForm } from './form.js';

document.addEventListener('DOMContentLoaded', () => {
  initUI();
  initRouter();

  window.addEventListener('page:loaded', (e) => {
    const page = e.detail?.page || '';
    if (page === 'cadastro') {
      initForm();
    }
  });
});